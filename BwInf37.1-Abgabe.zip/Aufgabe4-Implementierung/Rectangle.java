public class Rectangle {
    
    protected int height;
    protected int width;
    protected int area;
    protected int x;
    protected int y;
    
    public Rectangle(int width, int height){
        this.width = height;
        this.height = height;
    }
    
    
    
}
