public class Widerstand {
  public int wert;
  
  public Widerstand(int ohm) {
    this.wert=ohm;
  }
}
